
  # Mini-CRM Lead System UI

  This is a code bundle for Mini-CRM Lead System UI. The original project is available at https://www.figma.com/design/lyHSUkDzSBbAdu5gLehoe3/Mini-CRM-Lead-System-UI.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  