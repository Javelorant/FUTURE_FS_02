export type LeadStatus = 'new' | 'contacted' | 'qualified' | 'proposal' | 'negotiation' | 'won' | 'lost';

export type LeadSource = 'website' | 'referral' | 'social-media' | 'email-campaign' | 'cold-call' | 'event';

export interface Lead {
  id: string;
  firstName: string;
  lastName: string;
  email: string;
  phone: string;
  company: string;
  position: string;
  status: LeadStatus;
  source: LeadSource;
  value: number;
  notes: string;
  createdAt: string;
  lastContact: string;
}
