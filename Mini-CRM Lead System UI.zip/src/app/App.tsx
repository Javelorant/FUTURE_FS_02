import { useState } from 'react';
import { Lead, LeadStatus, LeadSource } from './types/lead';
import { mockLeads } from './data/mockLeads';
import { StatsCards } from './components/StatsCards';
import { LeadsTable } from './components/LeadsTable';
import { LeadDialog } from './components/LeadDialog';
import { LeadDetailsSheet } from './components/LeadDetailsSheet';
import { Button } from './components/ui/button';
import { Input } from './components/ui/input';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from './components/ui/select';
import { Plus, Search, Filter } from 'lucide-react';
import { toast } from 'sonner';
import { Toaster } from './components/ui/sonner';

export default function App() {
  const [leads, setLeads] = useState<Lead[]>(mockLeads);
  const [searchQuery, setSearchQuery] = useState('');
  const [statusFilter, setStatusFilter] = useState<LeadStatus | 'all'>('all');
  const [sourceFilter, setSourceFilter] = useState<LeadSource | 'all'>('all');
  const [isDialogOpen, setIsDialogOpen] = useState(false);
  const [isDetailsOpen, setIsDetailsOpen] = useState(false);
  const [selectedLead, setSelectedLead] = useState<Lead | null>(null);
  const [editingLead, setEditingLead] = useState<Lead | undefined>(undefined);

  // Filter leads based on search and filters
  const filteredLeads = leads.filter((lead) => {
    const matchesSearch = 
      searchQuery === '' ||
      lead.firstName.toLowerCase().includes(searchQuery.toLowerCase()) ||
      lead.lastName.toLowerCase().includes(searchQuery.toLowerCase()) ||
      lead.email.toLowerCase().includes(searchQuery.toLowerCase()) ||
      lead.company.toLowerCase().includes(searchQuery.toLowerCase());

    const matchesStatus = statusFilter === 'all' || lead.status === statusFilter;
    const matchesSource = sourceFilter === 'all' || lead.source === sourceFilter;

    return matchesSearch && matchesStatus && matchesSource;
  });

  const handleSaveLead = (lead: Lead) => {
    const existingIndex = leads.findIndex((l) => l.id === lead.id);
    
    if (existingIndex >= 0) {
      // Update existing lead
      const updatedLeads = [...leads];
      updatedLeads[existingIndex] = lead;
      setLeads(updatedLeads);
      toast.success('Lead updated successfully');
    } else {
      // Add new lead
      setLeads([lead, ...leads]);
      toast.success('Lead added successfully');
    }
    
    setEditingLead(undefined);
  };

  const handleViewLead = (lead: Lead) => {
    setSelectedLead(lead);
    setIsDetailsOpen(true);
  };

  const handleEditLead = (lead: Lead) => {
    setEditingLead(lead);
    setIsDetailsOpen(false);
    setIsDialogOpen(true);
  };

  const handleDeleteLead = (lead: Lead) => {
    if (confirm(`Are you sure you want to delete ${lead.firstName} ${lead.lastName}?`)) {
      setLeads(leads.filter((l) => l.id !== lead.id));
      setIsDetailsOpen(false);
      toast.success('Lead deleted successfully');
    }
  };

  const handleAddNew = () => {
    setEditingLead(undefined);
    setIsDialogOpen(true);
  };

  const activeFiltersCount = 
    (statusFilter !== 'all' ? 1 : 0) + 
    (sourceFilter !== 'all' ? 1 : 0);

  return (
    <div className="min-h-screen bg-gray-50">
      <Toaster />
      
      {/* Header */}
      <div className="bg-white border-b">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6">
          <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
            <div>
              <h1 className="text-3xl font-bold text-gray-900">CRM Lead System</h1>
              <p className="text-sm text-muted-foreground mt-1">
                Manage and track your sales leads
              </p>
            </div>
            <Button onClick={handleAddNew} size="lg">
              <Plus className="size-4 mr-2" />
              Add Lead
            </Button>
          </div>
        </div>
      </div>

      {/* Main Content */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Stats */}
        <div className="mb-8">
          <StatsCards leads={leads} />
        </div>

        {/* Filters */}
        <div className="bg-white rounded-lg border p-4 mb-6">
          <div className="flex flex-col lg:flex-row gap-4">
            <div className="flex-1">
              <div className="relative">
                <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 size-4 text-muted-foreground" />
                <Input
                  placeholder="Search leads by name, email, or company..."
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  className="pl-10"
                />
              </div>
            </div>
            
            <div className="flex gap-2 items-center">
              <Filter className="size-4 text-muted-foreground" />
              <Select value={statusFilter} onValueChange={(value) => setStatusFilter(value as LeadStatus | 'all')}>
                <SelectTrigger className="w-[160px]">
                  <SelectValue placeholder="Status" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All Statuses</SelectItem>
                  <SelectItem value="new">New</SelectItem>
                  <SelectItem value="contacted">Contacted</SelectItem>
                  <SelectItem value="qualified">Qualified</SelectItem>
                  <SelectItem value="proposal">Proposal</SelectItem>
                  <SelectItem value="negotiation">Negotiation</SelectItem>
                  <SelectItem value="won">Won</SelectItem>
                  <SelectItem value="lost">Lost</SelectItem>
                </SelectContent>
              </Select>

              <Select value={sourceFilter} onValueChange={(value) => setSourceFilter(value as LeadSource | 'all')}>
                <SelectTrigger className="w-[160px]">
                  <SelectValue placeholder="Source" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All Sources</SelectItem>
                  <SelectItem value="website">Website</SelectItem>
                  <SelectItem value="referral">Referral</SelectItem>
                  <SelectItem value="social-media">Social Media</SelectItem>
                  <SelectItem value="email-campaign">Email Campaign</SelectItem>
                  <SelectItem value="cold-call">Cold Call</SelectItem>
                  <SelectItem value="event">Event</SelectItem>
                </SelectContent>
              </Select>

              {activeFiltersCount > 0 && (
                <Button
                  variant="ghost"
                  size="sm"
                  onClick={() => {
                    setStatusFilter('all');
                    setSourceFilter('all');
                  }}
                >
                  Clear ({activeFiltersCount})
                </Button>
              )}
            </div>
          </div>
          
          <div className="mt-3 text-sm text-muted-foreground">
            Showing {filteredLeads.length} of {leads.length} leads
          </div>
        </div>

        {/* Table */}
        <div className="bg-white rounded-lg border">
          <LeadsTable
            leads={filteredLeads}
            onView={handleViewLead}
            onEdit={handleEditLead}
            onDelete={handleDeleteLead}
          />
        </div>
      </div>

      {/* Dialogs */}
      <LeadDialog
        open={isDialogOpen}
        onOpenChange={setIsDialogOpen}
        lead={editingLead}
        onSave={handleSaveLead}
      />

      <LeadDetailsSheet
        open={isDetailsOpen}
        onOpenChange={setIsDetailsOpen}
        lead={selectedLead}
        onEdit={() => selectedLead && handleEditLead(selectedLead)}
      />
    </div>
  );
}
