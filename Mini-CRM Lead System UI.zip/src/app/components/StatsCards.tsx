import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { Users, TrendingUp, DollarSign, CheckCircle } from 'lucide-react';
import { Lead } from '../types/lead';

interface StatsCardsProps {
  leads: Lead[];
}

export function StatsCards({ leads }: StatsCardsProps) {
  const totalLeads = leads.length;
  const activeLeads = leads.filter(l => !['won', 'lost'].includes(l.status)).length;
  const wonLeads = leads.filter(l => l.status === 'won').length;
  const totalValue = leads.reduce((sum, lead) => sum + lead.value, 0);
  const wonValue = leads.filter(l => l.status === 'won').reduce((sum, lead) => sum + lead.value, 0);
  const conversionRate = totalLeads > 0 ? ((wonLeads / totalLeads) * 100).toFixed(1) : '0';

  const stats = [
    {
      title: 'Total Leads',
      value: totalLeads.toString(),
      description: `${activeLeads} active`,
      icon: Users,
      iconColor: 'text-blue-500',
      bgColor: 'bg-blue-50'
    },
    {
      title: 'Conversion Rate',
      value: `${conversionRate}%`,
      description: `${wonLeads} won deals`,
      icon: TrendingUp,
      iconColor: 'text-green-500',
      bgColor: 'bg-green-50'
    },
    {
      title: 'Pipeline Value',
      value: `$${(totalValue / 1000).toFixed(0)}k`,
      description: 'Estimated total',
      icon: DollarSign,
      iconColor: 'text-purple-500',
      bgColor: 'bg-purple-50'
    },
    {
      title: 'Revenue Won',
      value: `$${(wonValue / 1000).toFixed(0)}k`,
      description: 'Closed deals',
      icon: CheckCircle,
      iconColor: 'text-emerald-500',
      bgColor: 'bg-emerald-50'
    }
  ];

  return (
    <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
      {stats.map((stat) => {
        const Icon = stat.icon;
        return (
          <Card key={stat.title}>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">
                {stat.title}
              </CardTitle>
              <div className={`p-2 rounded-lg ${stat.bgColor}`}>
                <Icon className={`size-4 ${stat.iconColor}`} />
              </div>
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">{stat.value}</div>
              <p className="text-xs text-muted-foreground mt-1">
                {stat.description}
              </p>
            </CardContent>
          </Card>
        );
      })}
    </div>
  );
}
