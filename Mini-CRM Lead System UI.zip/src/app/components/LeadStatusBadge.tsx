import { Badge } from './ui/badge';
import { LeadStatus } from '../types/lead';

interface LeadStatusBadgeProps {
  status: LeadStatus;
}

export function LeadStatusBadge({ status }: LeadStatusBadgeProps) {
  const statusConfig = {
    new: { label: 'New', className: 'bg-blue-500 hover:bg-blue-600 text-white' },
    contacted: { label: 'Contacted', className: 'bg-purple-500 hover:bg-purple-600 text-white' },
    qualified: { label: 'Qualified', className: 'bg-cyan-500 hover:bg-cyan-600 text-white' },
    proposal: { label: 'Proposal', className: 'bg-orange-500 hover:bg-orange-600 text-white' },
    negotiation: { label: 'Negotiation', className: 'bg-yellow-600 hover:bg-yellow-700 text-white' },
    won: { label: 'Won', className: 'bg-green-500 hover:bg-green-600 text-white' },
    lost: { label: 'Lost', className: 'bg-gray-500 hover:bg-gray-600 text-white' }
  };

  const config = statusConfig[status];

  return (
    <Badge className={config.className}>
      {config.label}
    </Badge>
  );
}
