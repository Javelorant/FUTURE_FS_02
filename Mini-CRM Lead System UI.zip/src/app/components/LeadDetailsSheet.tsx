import {
  Sheet,
  SheetContent,
  SheetDescription,
  SheetHeader,
  SheetTitle,
} from './ui/sheet';
import { Lead } from '../types/lead';
import { LeadStatusBadge } from './LeadStatusBadge';
import { Button } from './ui/button';
import { Mail, Phone, Building2, Briefcase, DollarSign, Calendar, Users, Edit } from 'lucide-react';
import { format } from 'date-fns';

interface LeadDetailsSheetProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  lead: Lead | null;
  onEdit: () => void;
}

export function LeadDetailsSheet({ open, onOpenChange, lead, onEdit }: LeadDetailsSheetProps) {
  if (!lead) return null;

  const sourceLabels: Record<string, string> = {
    'website': 'Website',
    'referral': 'Referral',
    'social-media': 'Social Media',
    'email-campaign': 'Email Campaign',
    'cold-call': 'Cold Call',
    'event': 'Event'
  };

  return (
    <Sheet open={open} onOpenChange={onOpenChange}>
      <SheetContent className="w-full sm:max-w-xl overflow-y-auto">
        <SheetHeader>
          <SheetTitle className="text-2xl">
            {lead.firstName} {lead.lastName}
          </SheetTitle>
          <SheetDescription>
            Lead Details and Contact Information
          </SheetDescription>
        </SheetHeader>

        <div className="mt-6 space-y-6">
          {/* Status */}
          <div>
            <p className="text-sm text-muted-foreground mb-2">Status</p>
            <LeadStatusBadge status={lead.status} />
          </div>

          {/* Contact Information */}
          <div className="space-y-3">
            <h3 className="font-semibold">Contact Information</h3>
            <div className="space-y-2">
              <div className="flex items-center gap-3 text-sm">
                <Mail className="size-4 text-muted-foreground" />
                <a href={`mailto:${lead.email}`} className="text-blue-600 hover:underline">
                  {lead.email}
                </a>
              </div>
              <div className="flex items-center gap-3 text-sm">
                <Phone className="size-4 text-muted-foreground" />
                <a href={`tel:${lead.phone}`} className="hover:underline">
                  {lead.phone}
                </a>
              </div>
            </div>
          </div>

          {/* Company Information */}
          <div className="space-y-3">
            <h3 className="font-semibold">Company Information</h3>
            <div className="space-y-2">
              <div className="flex items-center gap-3 text-sm">
                <Building2 className="size-4 text-muted-foreground" />
                <span>{lead.company}</span>
              </div>
              <div className="flex items-center gap-3 text-sm">
                <Briefcase className="size-4 text-muted-foreground" />
                <span>{lead.position}</span>
              </div>
            </div>
          </div>

          {/* Lead Details */}
          <div className="space-y-3">
            <h3 className="font-semibold">Lead Details</h3>
            <div className="space-y-2">
              <div className="flex items-center gap-3 text-sm">
                <DollarSign className="size-4 text-muted-foreground" />
                <span>Estimated Value: ${lead.value.toLocaleString()}</span>
              </div>
              <div className="flex items-center gap-3 text-sm">
                <Users className="size-4 text-muted-foreground" />
                <span>Source: {sourceLabels[lead.source] || lead.source}</span>
              </div>
              <div className="flex items-center gap-3 text-sm">
                <Calendar className="size-4 text-muted-foreground" />
                <span>Created: {format(new Date(lead.createdAt), 'MMM dd, yyyy')}</span>
              </div>
              <div className="flex items-center gap-3 text-sm">
                <Calendar className="size-4 text-muted-foreground" />
                <span>Last Contact: {format(new Date(lead.lastContact), 'MMM dd, yyyy')}</span>
              </div>
            </div>
          </div>

          {/* Notes */}
          {lead.notes && (
            <div className="space-y-3">
              <h3 className="font-semibold">Notes</h3>
              <p className="text-sm text-muted-foreground whitespace-pre-wrap">
                {lead.notes}
              </p>
            </div>
          )}

          {/* Actions */}
          <div className="pt-4 border-t">
            <Button onClick={onEdit} className="w-full">
              <Edit className="size-4 mr-2" />
              Edit Lead
            </Button>
          </div>
        </div>
      </SheetContent>
    </Sheet>
  );
}
